exports.white = $color("#ffffff");
exports.defaultText = $color("#333333");
exports.selectedText = $color("#157efb");
exports.lightBackground = $color("#F0F0F0");